import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import random

# Initialize an empty task list
tasks = pd.DataFrame(columns=['description', 'priority'])

# Load pre-existing tasks from a CSV file (if any)
try:
    tasks = pd.read_csv('tasks.csv')
except FileNotFoundError:
    pass

# Function to save tasks to a CSV file
def save_tasks(tasks_df):
    try:
        tasks_df.to_csv('tasks.csv', index=False)
    except Exception as e:
        print(f"Error saving tasks to CSV: {e}")

# Train the task priority classifier
vectorizer = CountVectorizer()
clf = MultinomialNB()
model = make_pipeline(vectorizer, clf)

# Function to train the model
def train_model(tasks_df):
    model.fit(tasks_df['description'], tasks_df['priority'])

# Function to add a task to the list
def add_task(tasks_df, description, priority):
    new_task = pd.DataFrame({'description': [description], 'priority': [priority]})
    tasks_df = pd.concat([tasks_df, new_task], ignore_index=True)
    save_tasks(tasks_df)
    train_model(tasks_df)  # Retrain the model after adding a task
    return tasks_df

# Function to remove a task by description
def remove_task(tasks_df, description):
    tasks_df = tasks_df[tasks_df['description'] != description]
    save_tasks(tasks_df)
    train_model(tasks_df)  # Retrain the model after removing a task
    return tasks_df

# Function to list all tasks
def list_tasks(tasks_df):
    if tasks_df.empty:
        print("No tasks available.")
    else:
        print(tasks_df)

# Function to recommend a task based on machine learning
def recommend_task(tasks_df):
    if not tasks_df.empty:
        # Get high-priority tasks
        high_priority_tasks = tasks_df[tasks_df['priority'] == 'High']

        if not high_priority_tasks.empty and 'description' in high_priority_tasks.columns:
            # Check if 'description' column is not empty or does not contain NaN values
            non_empty_descriptions = high_priority_tasks['description'].dropna()

            if not non_empty_descriptions.empty:
                # Print available indices for debugging
                print("Available indices in non_empty_descriptions:", non_empty_descriptions.index)

                # Check if there are available indices
                if not non_empty_descriptions.index.empty:
                    # Choose a random index
                    random_index = random.choice(non_empty_descriptions.index)
                    # Get the task description associated with the random index
                    random_task = non_empty_descriptions.loc[random_index]
                    print(f"Recommended task: {random_task} - Priority: High")
                else:
                    print("No available indices in non_empty_descriptions.")
            else:
                print("No non-empty descriptions available for high-priority tasks.")
        else:
            print("No high-priority tasks available for recommendation.")
    else:
        print("No tasks available for recommendations.")





# Main menu
while True:
    print("\nTask Management App")
    print("1. Add Task")
    print("2. Remove Task")
    print("3. List Tasks")
    print("4. Recommend Task")
    print("5. Exit")

    choice = input("Select an option: ")

    if choice == "1":
        description = input("Enter task description: ")
        priority = input("Enter task priority (Low/Medium/High): ").capitalize()
        tasks = add_task(tasks, description, priority)
        print("Task added successfully.")

    elif choice == "2":
        description = input("Enter task description to remove: ")
        tasks = remove_task(tasks, description)
        print("Task removed successfully.")

    elif choice == "3":
        list_tasks(tasks)

    elif choice == "4":
        recommend_task(tasks)

    elif choice == "5":
        print("Goodbye!")
        break

    else:
        print("Invalid option. Please select a valid option.")
